package homework.test.ds.algorithm;

import homework.test.ds.dataStructure.*;

import java.util.*;

public class Algorithm {
    private static int[] d;

    // 最短路，没有边数限制
    public static List<Integer> minPathNode(Graph g, int flag, int start, int ed) {
        int[] pre = dijkstra(g, flag, start, ed);
        List<Integer> ans = new ArrayList<>();
        for (Integer i = ed; i != start; i = pre[i]) {
            ans.add(i);
        }
        ans.add(start);
        Collections.reverse(ans);

        return ans;
    }
    // 最短路，有边数限制
    public static List<Integer> minPathNode(Graph g, int flag, int start, int ed, int k) {
        int[] pre = bellmanFord(g, flag, start, ed, k);
        if (pre == null) return null;
        List<Integer> ans = new ArrayList<>();
        for (Integer i = ed; i != start; i = pre[i]) {
            ans.add(i);
        }
        ans.add(start);
        Collections.reverse(ans);
        return ans;
    }
    // 根据点找边，最小花费
    public List<Edge> minMoneyPathEdges(Graph g, List<Integer> nodes) {
        List<Edge>[] edges = g.getEdges();
        List<Edge> ans = new ArrayList<>();
        Integer[] st = nodes.toArray(new Integer[nodes.size()]);
        for (int i = 0; i + 1 < st.length; i++) {
            int u = st[i], v = st[i + 1];
            Edge temp = new Edge();
            for (Edge e : edges[u]) {
                if (e.getNoOfDestination() == v && e.getMoneyCost() < temp.getMoneyCost()) {
                    temp = e;
                }
            }
            ans.add(temp);
        }
        return ans;
    }
    // 根据点找边，最小时间
    public List<Edge> minTimePathEdges(Graph g, List<Integer> nodes) {
        List<Edge>[] edges = g.getEdges();
        List<Edge> ans = new ArrayList<>();
        Integer[] st = nodes.toArray(new Integer[nodes.size()]);
        for (int i = 0; i + 1 < st.length; i++) {
            int u = st[i], v = st[i + 1];
            Edge temp = new Edge();
            for (Edge e : edges[u]) {
                if (e.getNoOfDestination() == v && e.getTimeCost() < temp.getTimeCost()) {
                    temp = e;
                }
            }
            ans.add(temp);
        }
        return ans;
    }
    // 根据点找边，最小风险
    public List<Edge> minRiskPathEdges(Graph g, List<Integer> nodes) {
        List<Edge>[] edges = g.getEdges();
        List<Edge> ans = new ArrayList<>();
        Integer[] st = nodes.toArray(new Integer[nodes.size()]);
        for (int i = 0; i + 1 < st.length; i++) {
            int u = st[i], v = st[i + 1];
            Edge temp = new Edge();
            for (Edge e : edges[u]) {
                if (e.getNoOfDestination() == v && e.getRisk() < temp.getRisk()) {
                    temp = e;
                }
            }
            ans.add(temp);
        }
        return ans;
    }
    // 求花费
    public Integer moneyCosts(List<Edge> edgeList) {
        Integer ans = 0;
        for (Edge e : edgeList) {
            ans += e.getMoneyCost();
        }
        return ans;
    }
    // 求时间，返回秒
    public Integer timeCosts(List<Edge> edgeList) {
        Integer ans = 0;
        Edge[] e = edgeList.toArray(edgeList.toArray(new Edge[edgeList.size()]));
        int m = e.length;
        for (int i = 0; i + 1 < m; i++) {
            ans += e[i].getTimeCost() + (int)(e[i + 1].getStartTime().getTime() / 1000) - (int)(e[i].getEndTime().getTime() / 1000);
        }
        ans += e[m - 1].getTimeCost();
        return ans;
    }
    // 求风险值
    public Integer risks(List<Edge> edgeList) {
        Integer ans = 0;
        for (Edge e : edgeList) {
            ans += e.getRisk();
        }
        return ans;
    }
    // Dijkstra 算法求最短路，用小根堆优化
    public static int[] dijkstra(Graph g, int flag, int start, int ed) {
        List<Edge>[] edges = g.getEdges();
        int n = g.getNumOfNode() + 1, m = g.getNumOfEdge() + 1;
        boolean[] st = new boolean[n];
        d = new int[n];
        for (int i = 0; i < n; i++) {
            d[i] = 0x3f3f3f3f;
        }
        int pre[] = new int[n];
        d[start] = 0;
        // 小根堆创建，使用优先队列
        PriorityQueue<Pair> hp = new PriorityQueue<>(new Comparator<Pair>() {
            @Override
            public int compare(Pair o1, Pair o2) {
                if (o1.first == o2.first) return o1.second - o2.second;
                return o1.first - o2.first;
            }
        });
        hp.offer(new Pair(0, start));
        while (hp.size() > 0) {
            Pair tp = hp.poll();
            int u = tp.second, dist = tp.first;
            if (st[u]) continue;
            st[u] = true;

            for (Edge it : edges[u]) {
                int j = it.getNoOfDestination();
                int w;
                if (flag == 1) w = it.getMoneyCost();
                else w = it.getTimeCost();
                if (d[j] > dist + w) {
                    d[j] = dist + w;
                    pre[j] = u;
                    hp.offer(new Pair(d[j], j));
                }
            }
        }
        System.out.println(d[ed]);
        return pre;
    }
    // Bellman-Ford 算法求解有边数限制的最短路
    public static int[] bellmanFord(Graph g, int flag, int start, int ed, int k) {
        List<Edge>[] edges = g.getEdges();
        int n = g.getNumOfNode() + 1, m = g.getNumOfEdge() + 1;
        d = new int[n];
        for (int i = 0; i < n; i++) {
            d[i] = 0x3f3f3f3f;
        }
        int pre[] = new int[n];
        Edge[] e = new Edge[m];
        int p = 0;
        for (int i = 1; i < n; i++) {
            for (Edge j : edges[i]) {
                e[++p] = j;
            }
        }
        d[start] = 0;
        for (int i = 1; i <= k; i++) {
            int[] bp = Arrays.copyOf(d, d.length);
            for (int j = 1; j < m; j++) {
                int u = e[j].getNoOfOrigin(), v = e[j].getNoOfDestination(), w;
                if (flag == 1) w = e[j].getMoneyCost();
                else w = e[j].getTimeCost();
                if (d[v] > bp[u] + w) {
                    d[v] = bp[u] + w;
                    pre[v] = u;
                }
            }
        }
        if (d[ed] > 0x3f3f3f3f / 2) return null;
        return pre;
    }
}