package homework.test.ds.dataStructure;

import java.util.*;

public class Graph {
    private Integer numOfNode; //节点数量
    private Integer numOfEdge; //边数量
    private List<Node> nodeList;
    private List<Edge> edgeList;
    private List<Edge> edges[]; //邻接表

    //无参构造方法
    public Graph() {
        numOfNode = 0;
        numOfEdge = 0;
        edges = new List[0x3f];
    }
    //带参构造方法
    public Graph(Integer numOfNode, Integer numOfEdge) {
        this.numOfNode = numOfNode;
        this.numOfEdge = numOfEdge;
        nodeList = new ArrayList<>();
        edgeList = new ArrayList<>();
        edges = new List[numOfNode + 1];
        for (int i = 0; i <= numOfNode; i++) {
            edges[i] = new ArrayList<>();
        }
    }

    public Integer getNumOfNode() {
        return numOfNode;
    }

    public void setNumOfNode(Integer numOfNode) {
        this.numOfNode = numOfNode;
    }

    public Integer getNumOfEdge() {
        return numOfEdge;
    }

    public void setNumOfEdge(Integer numOfEdge) {
        this.numOfEdge = numOfEdge;
    }

    public List<Edge>[] getEdges() {
        return edges;
    }

    public void setEdges(List<Edge>[] edges) {
        this.edges = edges;
    }

    public List<Node> getNodeList() {
        return nodeList;
    }

    public void setNodeList(List<Node> nodeList) {
        this.nodeList = nodeList;
    }

    public List<Edge> getEdgeList() {
        return edgeList;
    }

    public void setEdgeList(List<Edge> edgeList) {
        this.edgeList = edgeList;
    }

    public void addNode(Node p) {
        nodeList.add(p);
    }

    public void addEdge(Edge e) {
        int u = e.getNoOfOrigin();
        edges[u].add(e);
        edgeList.add(e);
    }

    public void dfs() {

    }

    public void bfs() {

    }
}
