package homework.test.ds.dataStructure;

public class Node {
    private Integer noOfNode;
    private String nameOfNode;
    private Integer riskGrade;

    public Node() {
        this.noOfNode = 0;
        this.nameOfNode = "";
        this.riskGrade = 0;
    }

    public Node(Integer noOfNode, String nameOfNode, Integer riskGrade) {
        this.noOfNode = noOfNode;
        this.nameOfNode = nameOfNode;
        this.riskGrade = riskGrade;
    }

    public Integer getNoOfNode() {
        return noOfNode;
    }

    public void setNoOfNode(Integer noOfNode) {
        this.noOfNode = noOfNode;
    }

    public String getNameOfNode() {
        return nameOfNode;
    }

    public void setNameOfNode(String nameOfNode) {
        this.nameOfNode = nameOfNode;
    }

    public Integer getRiskGrade() {
        return riskGrade;
    }

    public void setRiskGrade(Integer riskGrade) {
        this.riskGrade = riskGrade;
    }
}
