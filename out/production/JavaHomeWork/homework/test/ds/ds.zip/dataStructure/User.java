package homework.test.ds.dataStructure;

import java.util.ArrayList;
import java.util.List;

public class User {
    private Integer id;
    private String userName;
    private String e_mail;
    private String password;

    public User() {
        this.id = 0;
        this.userName = "";
        this.e_mail = "";
        this.password = "";
    }

    public User(Integer id, String userName, String e_mail, String password) {
        this.id = id;
        this.userName = userName;
        this.e_mail = e_mail;
        this.password = password;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getE_mail() {
        return e_mail;
    }

    public void setE_mail(String e_mail) {
        this.e_mail = e_mail;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
