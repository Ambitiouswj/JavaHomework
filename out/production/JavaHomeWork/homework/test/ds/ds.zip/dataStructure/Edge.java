package homework.test.ds.dataStructure;

import java.util.Date;

public class Edge {
    private Integer noOfOrigin;
    private Integer noOfDestination;
    private Integer typeOfEdge;
    private Integer moneyCost;
    private Integer timeCost;
    private Date startTime;
    private Date endTime;
    private String egName_1;
    private String egName_2;
    private Integer risk;

    public Edge() {
        this.moneyCost = 0x3f3f3f3f;
        this.timeCost = 0x3f3f3f3f;
        this.risk = 0x3f3f3f3f;
        this.noOfOrigin = 0;
        this.noOfDestination = 0;
        this.typeOfEdge = 0;
        this.startTime = null;
        this.endTime = null;
        this.egName_1 = this.egName_2 = "";
    }
    public Edge(Integer noOfOrigin, Integer noOfDestination, Integer typeOfEdge, Integer moneyCost, Integer timeCost, Date startTime, Date endTime, String egName) {
        this.noOfOrigin = noOfOrigin;
        this.noOfDestination = noOfDestination;
        this.typeOfEdge = typeOfEdge;
        this.moneyCost = moneyCost;
        this.timeCost = timeCost;
        this.startTime = startTime;
        this.endTime = endTime;
        this.egName_1 = this.egName_2 = egName;
        // 风险值 = max(起始地风险，目的地风险) + 交通工具风险（typeOfEdge）
        // this.risk =
    }

    public Edge(Integer noOfOrigin, Integer noOfDestination, Integer typeOfEdge, Integer moneyCost, Integer timeCost, Date startTime, Date endTime, String egName_1, String egName_2) {
        this.noOfOrigin = noOfOrigin;
        this.noOfDestination = noOfDestination;
        this.typeOfEdge = typeOfEdge;
        this.moneyCost = moneyCost;
        this.timeCost = timeCost;
        this.startTime = startTime;
        this.endTime = endTime;
        this.egName_1 = egName_1;
        this.egName_2 = egName_2;
    }

    public Integer getNoOfOrigin() {
        return noOfOrigin;
    }

    public void setNoOfOrigin(Integer noOfOrigin) {
        this.noOfOrigin = noOfOrigin;
    }

    public Integer getNoOfDestination() {
        return noOfDestination;
    }

    public void setNoOfDestination(Integer noOfDestination) {
        this.noOfDestination = noOfDestination;
    }

    public Integer getMoneyCost() {
        return moneyCost;
    }

    public void setMoneyCost(Integer moneyCost) {
        this.moneyCost = moneyCost;
    }

    public Integer getTimeCost() {
        return timeCost;
    }

    public void setTimeCost(Integer timeCost) {
        this.timeCost = timeCost;
    }

    public Integer getTypeOfEdge() {
        return typeOfEdge;
    }

    public void setTypeOfEdge(Integer typeOfEdge) {
        this.typeOfEdge = typeOfEdge;
    }

    public Integer getRisk() {
        return risk;
    }

    public void setRisk(Integer risk) {
        this.risk = risk;
    }

    private String getEgName_1() {
        return egName_1;
    }

    public void setEgName_1(String egName_1) {
        this.egName_1 = egName_1;
    }

    private String getEgName_2() {
        return egName_2;
    }

    public void setEgName_2(String egName_2) {
        this.egName_2 = egName_2;
    }

    public String getEgName() {
        if (egName_1.equals(egName_2)) return egName_1;
        String egName = "";
        int i = 0;
        while (egName_1.charAt(i) == egName_2.charAt(i)) {
            egName = egName + egName_1.charAt(i);
            i++;
        }
        egName = egName_1 + "/" + egName_2.substring(i);
        return egName;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }
}
