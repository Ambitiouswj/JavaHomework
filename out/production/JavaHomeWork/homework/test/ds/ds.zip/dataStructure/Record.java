package homework.test.ds.dataStructure;


import java.util.*;

public class Record {
    private Date startTime;
    private Date endTime;
    private Integer noOfOrigin;
    private Integer noOfTerminus;

    public Record() {
        this.startTime = null;
        this.endTime = null;
        this.noOfOrigin = 0;
        this.noOfTerminus = 0;
    }

    public Record(Date startTime, Date endTime, Integer noOfOrigin, Integer noOfTerminus) {
        this.startTime = startTime;
        this.endTime = endTime;
        this.noOfOrigin = noOfOrigin;
        this.noOfTerminus = noOfTerminus;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public Integer getNoOfOrigin() {
        return noOfOrigin;
    }

    public void setNoOfOrigin(Integer noOfOrigin) {
        this.noOfOrigin = noOfOrigin;
    }

    public Integer getNoOfTerminus() {
        return noOfTerminus;
    }

    public void setNoOfTerminus(Integer noOfTerminus) {
        this.noOfTerminus = noOfTerminus;
    }
}
